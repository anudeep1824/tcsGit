package com.orca.inventorymanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventorymanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
