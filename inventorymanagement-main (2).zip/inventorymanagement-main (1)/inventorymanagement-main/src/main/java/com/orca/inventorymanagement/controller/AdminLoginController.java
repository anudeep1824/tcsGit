//package com.orca.inventorymanagement.controller;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import javax.servlet.http.HttpSession;
//
//@Controller
//public class AdminLoginController {
//
//    @GetMapping("/login")
//    public String showLoginPage() {
//        return "login"; // Returns the login.html page
//    }
//
//    @PostMapping("/login")
//    public String handleLogin(
//            @RequestParam("email") String email,
//            @RequestParam("password") String password,
//            HttpSession session,
//            Model model) {
//
//        // VERY INSECURE: Hardcoded credentials for demonstration ONLY
//        if ("admin@gmail.com".equals(email) && "admin123".equals(password)) {
//            session.setAttribute("isAdmin", true); // Set a session attribute to indicate admin status
//            return "redirect:/admin/dashboard"; // Redirect to admin dashboard
//        } else {
//            // For other users, redirect to the regular dashboard (if you have one)
//            //  You might have your own logic to validate regular user credentials
//            //  and set session attributes accordingly.  For this example, I'm just
//            //  redirecting everyone else to a general "/dashboard"
//            return "redirect:/dashboard";
//        }
//    }
//
//    @GetMapping("/admin/dashboard")
//    public String adminDashboard(HttpSession session) {
//        // Check if the user is an admin
//        Boolean isAdmin = (Boolean) session.getAttribute("isAdmin");
//        if (isAdmin != null && isAdmin) {
//            return "admin/dashboard"; // Return the admin dashboard HTML
//        } else {
//            return "redirect:/login"; // Redirect to login if not an admin
//        }
//    }
//
//    @GetMapping("/dashboard")
//    public String dashboard(HttpSession session) {
//        //  check for regular user.
//        Boolean isAdmin = (Boolean) session.getAttribute("isAdmin");
//        if (isAdmin == null || !isAdmin) {
//            return "dashboard"; // Return the dashboard HTML
//        } else {
//            return "redirect:/login"; // Redirect to login if not a regular user
//        }
//    }
//
//    @GetMapping("/logout")
//    public String logout(HttpSession session) {
//        session.invalidate(); // Clear the entire session
//        return "redirect:/login"; // Redirect to login page after logout
//    }
//}
//
